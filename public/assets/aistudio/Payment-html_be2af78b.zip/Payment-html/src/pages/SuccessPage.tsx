import React, { useEffect, useState } from 'react';
import type { AppRoute, VerifiedTransaction } from '../types';
import {
  GooglePayIcon,
  PhonePeIcon,
  PaytmIcon,
  BhimIcon,
  CredIcon,
  AmazonPayIcon,
} from '../components/PaymentIcons';

interface SuccessPageProps {
  transaction: VerifiedTransaction | null;
  onNavigate: (route: AppRoute) => void;
}

export const SuccessPage: React.FC<SuccessPageProps> = ({ transaction, onNavigate }) => {
  const [countdown, setCountdown] = useState<number | null>(() => {
    return transaction?.redirectUrl ? 4 : null;
  });

  useEffect(() => {
    if (!transaction?.redirectUrl || countdown === null) return;

    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else if (countdown === 0) {
      const targetUrl = new URL(transaction.redirectUrl, window.location.origin);
      targetUrl.searchParams.set('orderId', transaction.orderId);
      targetUrl.searchParams.set('utr', transaction.utr);
      targetUrl.searchParams.set('status', 'SUCCESS');
      targetUrl.searchParams.set('amount', transaction.amount);
      window.location.href = targetUrl.toString();
    }
  }, [countdown, transaction]);

  if (!transaction) {
    return (
      <div className="white-card">
        <p className="payingamount" style={{ fontSize: '20px' }}>No Transaction</p>
        <p className="smalltext">No verified payment found.</p>
        <button
          type="button"
          onClick={() => onNavigate('pay')}
          className="createb"
          style={{ width: '100%', marginTop: '12px' }}
        >
          Go to Checkout
        </button>
      </div>
    );
  }

  const handleManualRedirect = () => {
    if (transaction.redirectUrl) {
      const targetUrl = new URL(transaction.redirectUrl, window.location.origin);
      targetUrl.searchParams.set('orderId', transaction.orderId);
      targetUrl.searchParams.set('utr', transaction.utr);
      targetUrl.searchParams.set('status', 'SUCCESS');
      targetUrl.searchParams.set('amount', transaction.amount);
      window.location.href = targetUrl.toString();
    } else {
      onNavigate('create');
    }
  };

  return (
    <div style={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <div className="white-card">
        <div
          style={{
            width: '60px',
            height: '60px',
            borderRadius: '50%',
            backgroundColor: '#059669',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '6px auto 14px',
            boxShadow: '0 6px 16px rgba(5, 150, 105, 0.25)',
          }}
        >
          <svg
            width="32"
            height="32"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#ffffff"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polyline points="20 6 9 17 4 12" />
          </svg>
        </div>

        <h2 style={{ fontSize: '20px', fontWeight: 800, color: '#111111', margin: '0 0 4px 0' }}>
          Payment Verified!
        </h2>
        <p style={{ color: '#059669', fontSize: '13px', fontWeight: 700, margin: '0 0 16px 0' }}>
          Transaction Confirmed
        </p>

        <div
          style={{
            width: '100%',
            backgroundColor: '#F9F8F6',
            border: '1px solid #EBE7DF',
            borderRadius: '14px',
            padding: '16px 14px',
            marginBottom: '16px',
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
            <span style={{ color: '#6B7280', fontSize: '12px' }}>Amount Paid</span>
            <span style={{ color: '#111111', fontSize: '16px', fontWeight: 800 }}>
              ₹{transaction.amount}
            </span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
            <span style={{ color: '#6B7280', fontSize: '12px' }}>Order ID</span>
            <span style={{ color: '#111111', fontSize: '12px', fontWeight: 700, fontFamily: 'monospace' }}>
              {transaction.orderId}
            </span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
            <span style={{ color: '#6B7280', fontSize: '12px' }}>UPI Ref / UTR</span>
            <span style={{ color: '#111111', fontSize: '12px', fontWeight: 700, fontFamily: 'monospace' }}>
              {transaction.utr}
            </span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ color: '#6B7280', fontSize: '12px' }}>Date & Time</span>
            <span style={{ color: '#6B7280', fontSize: '11px' }}>
              {transaction.timestamp}
            </span>
          </div>
        </div>

        {transaction.redirectUrl ? (
          <div style={{ width: '100%', textAlign: 'center' }}>
            <p style={{ color: '#6B7280', fontSize: '12px', margin: '0 0 10px 0' }}>
              Redirecting to your store in{' '}
              <strong style={{ color: '#111111', fontSize: '14px' }}>{countdown}s</strong>...
            </p>
            <button
              type="button"
              onClick={handleManualRedirect}
              className="createb"
              style={{ width: '100%', padding: '11px', fontSize: '14px' }}
            >
              CONTINUE TO STORE NOW
            </button>
          </div>
        ) : (
          <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <button
              type="button"
              onClick={() => onNavigate('create')}
              className="createb"
              style={{ width: '100%', padding: '11px', fontSize: '14px' }}
            >
              CREATE NEW LINK
            </button>
          </div>
        )}
      </div>

      {/* Clean T&C text and UPI logo with authentic payment app icons */}
      <div style={{ textAlign: 'center', marginTop: '16px', padding: '0 10px', maxWidth: '360px' }}>
        <p className="smalltext" style={{ margin: '0 0 10px 0', fontSize: '11px', color: '#6B7280' }}>
          If you have any Question about security or privacy, Check our{' '}
          <a
            href="#tos"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('tos');
            }}
            style={{ color: '#111111', textDecoration: 'underline', fontWeight: 700 }}
          >
            T&C
          </a>
          .
        </p>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexWrap: 'wrap',
            gap: '8px',
            marginTop: '6px',
          }}
        >
          <img
            src="/img/upi.svg"
            alt="UPI Logo"
            className="upilogo"
            width="44"
            height="22"
          />
          <GooglePayIcon size={24} />
          <PhonePeIcon size={24} />
          <PaytmIcon size={24} />
          <BhimIcon size={24} />
          <CredIcon size={24} />
          <AmazonPayIcon size={24} />
        </div>
      </div>
    </div>
  );
};
