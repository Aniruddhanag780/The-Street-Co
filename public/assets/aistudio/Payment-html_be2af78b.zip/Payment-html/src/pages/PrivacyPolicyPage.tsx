import React from 'react';

export const PrivacyPolicyPage: React.FC = () => {
  return (
    <div className="contentdiv-tos">
      <p className="txt">
        At Upier, accessible from https://upier.t-ps.net, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by Upier and how we use it.
      </p>
      <p className="txt">
        If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.
      </p>
      <p className="txt">
        This Privacy Policy applies only to our online activities and is valid for visitors to our website with regards to the information that they shared and/or collect in Upier. This policy is not applicable to any information collected offline or via channels other than this website.
      </p>

      <h2 className="consent">Consent</h2>
      <p className="txt">
        By using our website, you hereby consent to our Privacy Policy and agree to its terms.
        <br />
        <br />
        • We don't collect any Information.
        <br />
        • We don't Log You.
        <br />
        • We don't Have any Advertise on our site.
      </p>

      <p className="sign">- Tuhin Kanti Pal</p>
      <p className="signcontent">
        (Developer and Creator of{' '}
        <a
          href="https://github.com/cachecleanerjeet/Upier"
          target="_blank"
          rel="noopener noreferrer"
        >
          UPIER
        </a>
        )
        <br />
        <a
          href="https://github.com/cachecleanerjeet/"
          target="_blank"
          rel="noopener noreferrer"
        >
          G I T H U B
        </a>
      </p>

      <p className="txt">
        For contact send an email to:
        <br />
        <a href="mailto:me@thetuhin.com" className="contact-email">
          me@thetuhin.com
        </a>
      </p>

    </div>
  );
};
