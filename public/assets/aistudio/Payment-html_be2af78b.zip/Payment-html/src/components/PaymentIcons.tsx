import React from 'react';

export const GooglePayIcon: React.FC<{ size?: number; className?: string }> = ({ size = 28, className }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    role="img"
    aria-label="Google Pay"
  >
    <title>Google Pay</title>
    <rect width="48" height="48" rx="10" fill="#FFFFFF" stroke="#E5E7EB" strokeWidth="1.5" />
    <path
      d="M33.6 24.3c0-.7-.1-1.3-.2-1.9H24v3.8h5.4c-.2 1.2-.9 2.2-1.9 2.9v2.4h3.1c1.8-1.7 2.9-4.2 2.9-7.2z"
      fill="#4285F4"
    />
    <path
      d="M24 34c2.7 0 5-0.9 6.6-2.4l-3.1-2.4c-.9.6-2 1-3.5 1-2.7 0-4.9-1.8-5.7-4.2h-3.2v2.5C16.8 31.7 20.1 34 24 34z"
      fill="#34A853"
    />
    <path
      d="M18.3 26c-.2-.6-.3-1.3-.3-2s.1-1.4.3-2v-2.5h-3.2C14.4 20.9 14 22.4 14 24s.4 3.1 1.1 4.5l3.2-2.5z"
      fill="#FBBC05"
    />
    <path
      d="M24 17.8c1.5 0 2.8.5 3.8 1.5l2.9-2.9C29 14.8 26.7 14 24 14c-3.9 0-7.2 2.3-8.9 5.5l3.2 2.5c.8-2.4 3-4.2 5.7-4.2z"
      fill="#EA4335"
    />
  </svg>
);

export const PhonePeIcon: React.FC<{ size?: number; className?: string }> = ({ size = 28, className }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    role="img"
    aria-label="PhonePe"
  >
    <title>PhonePe</title>
    <rect width="48" height="48" rx="10" fill="#5F259F" />
    <path
      d="M27.5 13H18.8c-.8 0-1.5.7-1.5 1.5v18.7c0 .7.6 1.3 1.3 1.3h2.8c.7 0 1.3-.6 1.3-1.3v-5.2h4.7c4.6 0 8.3-3.7 8.3-8.3s-3.6-6.7-8.2-6.7zm0 8.4h-4.8v-3.7h4.8c1.3 0 2.4 1.1 2.4 2.4s-1.1 2.3-2.4 2.3z"
      fill="#FFFFFF"
    />
    <path
      d="M24.8 26.8l5.8 7.6c.4.6 1.1.9 1.8.9h2.9c.8 0 1.3-1 .8-1.7l-6-7.8c-.5-.6-1.3-.9-2.1-.9h-3.2v1.9z"
      fill="#FFFFFF"
    />
  </svg>
);

export const PaytmIcon: React.FC<{ size?: number; className?: string }> = ({ size = 28, className }) => (
  <svg
    width={size * 1.5}
    height={size}
    viewBox="0 0 72 32"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    role="img"
    aria-label="Paytm"
  >
    <title>Paytm</title>
    <rect width="72" height="32" rx="7" fill="#FFFFFF" stroke="#E5E7EB" strokeWidth="1.2" />
    <text
      x="8"
      y="22"
      fill="#002E6E"
      fontFamily="'Poppins', sans-serif"
      fontSize="16"
      fontWeight="900"
    >
      Pay
    </text>
    <text
      x="43"
      y="22"
      fill="#00BAF2"
      fontFamily="'Poppins', sans-serif"
      fontSize="16"
      fontWeight="900"
    >
      tm
    </text>
  </svg>
);

export const BhimIcon: React.FC<{ size?: number; className?: string }> = ({ size = 28, className }) => (
  <svg
    width={size * 1.4}
    height={size}
    viewBox="0 0 68 32"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    role="img"
    aria-label="BHIM"
  >
    <title>BHIM</title>
    <rect width="68" height="32" rx="7" fill="#FFFFFF" stroke="#E5E7EB" strokeWidth="1.2" />
    <path d="M12 22L17.5 10H14L10 19l-1-7H6l2 10h4z" fill="#00796B" />
    <path d="M19 10h2.5l2 4 2-4H28l-3 6 3.2 6H25.5l-2.2-4.2L21 22h-2V10z" fill="#00796B" />
    <path d="M34 10l-4 12h3.5l1.5-5h4l.5 5h3.5l-4-12H34zm1.8 4.5l1.2 3.5h-2.5l1.3-3.5z" fill="#00796B" />
    <path d="M54 11l-4 5 4 5" stroke="#FF6F00" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M59 11l-4 5 4 5" stroke="#00796B" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const CredIcon: React.FC<{ size?: number; className?: string }> = ({ size = 28, className }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    role="img"
    aria-label="CRED"
  >
    <title>CRED</title>
    <rect width="48" height="48" rx="10" fill="#0D0D0D" />
    <path
      d="M24 10a14 14 0 1 0 14 14h-4a10 10 0 1 1-10-10V10z"
      fill="#FFFFFF"
    />
    <rect x="22" y="20" width="10" height="4" rx="2" fill="#FFFFFF" />
  </svg>
);

export const AmazonPayIcon: React.FC<{ size?: number; className?: string }> = ({ size = 28, className }) => (
  <svg
    width={size * 1.4}
    height={size}
    viewBox="0 0 68 32"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    role="img"
    aria-label="Amazon Pay"
  >
    <title>Amazon Pay</title>
    <rect width="68" height="32" rx="7" fill="#FFFFFF" stroke="#E5E7EB" strokeWidth="1.2" />
    <text
      x="8"
      y="18"
      fill="#111111"
      fontFamily="'Poppins', sans-serif"
      fontSize="10"
      fontWeight="800"
    >
      amazon
    </text>
    <path
      d="M10 23c6 3 17 3 23-1"
      stroke="#FF9900"
      strokeWidth="2"
      strokeLinecap="round"
    />
    <path
      d="M32 20.5l2 1.5-1.5 2"
      stroke="#FF9900"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <text
      x="38"
      y="21"
      fill="#2563EB"
      fontFamily="'Poppins', sans-serif"
      fontSize="9"
      fontWeight="800"
    >
      pay
    </text>
  </svg>
);

export const PaymentAppsRow: React.FC<{ size?: number }> = ({ size = 28 }) => {
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexWrap: 'wrap',
        gap: '8px',
        margin: '10px 0',
      }}
    >
      <GooglePayIcon size={size} />
      <PhonePeIcon size={size} />
      <PaytmIcon size={size} />
      <BhimIcon size={size} />
      <CredIcon size={size} />
      <AmazonPayIcon size={size} />
    </div>
  );
};
