export type AppRoute = 'create' | 'pay' | 'success' | 'tos' | 'privacy-policy' | 'integration';

export const DEFAULT_VPA = 'aniruddhanag780@fam';
export const STORE_NAME = 'Aniruddha Store';

export interface PayParams {
  vpa: string | null;
  amount: string | null;
  orderId?: string | null;
  redirectUrl?: string | null;
  customerName?: string | null;
  note?: string | null;
}

export interface VerifiedTransaction {
  orderId: string;
  utr: string;
  amount: string;
  vpa: string;
  timestamp: string;
  status: 'SUCCESS' | 'PENDING';
  redirectUrl?: string | null;
}
