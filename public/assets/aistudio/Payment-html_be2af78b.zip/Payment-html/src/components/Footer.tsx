import React from 'react';
import type { AppRoute } from '../types';

interface FooterProps {
  currentRoute: AppRoute;
  onNavigate: (route: AppRoute) => void;
}

export const Footer: React.FC<FooterProps> = ({ currentRoute, onNavigate }) => {
  // On checkout, payment, and success screens, remove external footer so only card and clean T&C + UPI logo display
  if (currentRoute === 'create' || currentRoute === 'pay' || currentRoute === 'success') {
    return null;
  }

  return (
    <footer className="footerdiv" style={{ marginTop: '16px' }}>
      <p className="tpf" onClick={() => onNavigate('pay')} role="button" tabIndex={0}>
        <u>← Return to Payment</u>
      </p>
    </footer>
  );
};
