import React from 'react';
import type { AppRoute } from '../types';

interface HeaderProps {
  currentRoute: AppRoute;
  onNavigate: (route: AppRoute) => void;
  onShare?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentRoute }) => {
  if (currentRoute === 'create' || currentRoute === 'pay' || currentRoute === 'success') {
    return null;
  }

  if (currentRoute === 'tos') {
    return (
      <header className="headerdiv">
        <h1 className="heading-tos">Terms of Service</h1>
      </header>
    );
  }

  if (currentRoute === 'privacy-policy') {
    return (
      <header className="headerdiv">
        <h1 className="heading-tos">Privacy Policy</h1>
      </header>
    );
  }

  if (currentRoute === 'integration') {
    return (
      <header className="headerdiv">
        <h1 className="heading-tos">E-Commerce Setup</h1>
      </header>
    );
  }

  return null;
};
