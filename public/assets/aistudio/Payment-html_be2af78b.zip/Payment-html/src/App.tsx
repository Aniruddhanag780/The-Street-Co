import React, { useState, useEffect, useCallback } from 'react';
import { DEFAULT_VPA, type AppRoute, type PayParams } from './types';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CreatePage } from './pages/CreatePage';
import { PayPage } from './pages/PayPage';
import { TosPage } from './pages/TosPage';
import { PrivacyPolicyPage } from './pages/PrivacyPolicyPage';

function parseCurrentLocation(): { route: AppRoute; params: PayParams } {
  const path = window.location.pathname.replace(/\/$/, '') || '/';
  const urlParams = new URLSearchParams(window.location.search);
  const hash = window.location.hash.replace(/^#/, '');

  let route: AppRoute = 'create'; // 1st page as it was earlier
  if (path === '/pay' || hash === 'pay') {
    route = 'pay';
  } else if (path === '/tos' || hash === 'tos') {
    route = 'tos';
  } else if (path === '/privacy-policy' || hash === 'privacy-policy') {
    route = 'privacy-policy';
  }

  // If query string has amount or vpa directly on root, route to pay QR page
  if (urlParams.get('amount') || urlParams.get('vpa')) {
    route = 'pay';
  }

  return {
    route,
    params: {
      vpa: urlParams.get('vpa') || DEFAULT_VPA,
      amount: urlParams.get('amount'),
      orderId: urlParams.get('orderId'),
      redirectUrl: urlParams.get('redirectUrl') || urlParams.get('callbackUrl') || urlParams.get('returnUrl'),
      customerName: urlParams.get('customerName'),
      note: urlParams.get('note'),
    },
  };
}

export const App: React.FC = () => {
  const [currentRoute, setCurrentRoute] = useState<AppRoute>(() => parseCurrentLocation().route);
  const [payParams, setPayParams] = useState<PayParams>(() => parseCurrentLocation().params);
  const [shareToast, setShareToast] = useState<string | null>(null);

  const handleLocationChange = useCallback(() => {
    const loc = parseCurrentLocation();
    setCurrentRoute(loc.route);
    setPayParams(loc.params);
  }, []);

  useEffect(() => {
    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, [handleLocationChange]);

  const navigate = (
    newRoute: AppRoute,
    queryParams?: {
      vpa?: string;
      amount?: string;
      orderId?: string;
      redirectUrl?: string;
      note?: string;
    }
  ) => {
    let newPath = '/';
    const params = new URLSearchParams();

    if (newRoute === 'create') {
      newPath = '/';
    } else if (newRoute === 'pay') {
      newPath = '/pay';
      if (queryParams?.amount) params.set('amount', queryParams.amount);
      if (queryParams?.vpa) params.set('vpa', queryParams.vpa);
    } else if (newRoute === 'tos') {
      newPath = '/tos';
    } else if (newRoute === 'privacy-policy') {
      newPath = '/privacy-policy';
    }

    const searchStr = params.toString();
    const finalUrl = searchStr ? `${newPath}?${searchStr}` : newPath;

    window.history.pushState(null, '', finalUrl);
    setCurrentRoute(newRoute);
    setPayParams({
      vpa: queryParams?.vpa || payParams.vpa || DEFAULT_VPA,
      amount: queryParams?.amount !== undefined ? queryParams.amount : payParams.amount,
      orderId: queryParams?.orderId !== undefined ? queryParams.orderId : payParams.orderId,
      redirectUrl: queryParams?.redirectUrl !== undefined ? queryParams.redirectUrl : payParams.redirectUrl,
      note: queryParams?.note !== undefined ? queryParams.note : payParams.note,
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleShare = async () => {
    const shareData = {
      title: 'Upier',
      text: "*Upier* \n\nShareable Secure Payment's Link for UPI :\n",
      url: window.location.href,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          copyCurrentUrl();
        }
      }
    } else {
      copyCurrentUrl();
    }
  };

  const copyCurrentUrl = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setShareToast('Link copied to clipboard!');
      setTimeout(() => setShareToast(null), 3000);
    } catch {
      setShareToast('Share URL: ' + window.location.href);
      setTimeout(() => setShareToast(null), 4000);
    }
  };

  return (
    <div className="app-wrapper">
      {shareToast && (
        <div
          style={{
            position: 'fixed',
            top: '20px',
            backgroundColor: '#000000',
            color: '#ffffff',
            padding: '8px 18px',
            borderRadius: '20px',
            fontSize: '12px',
            fontWeight: 700,
            zIndex: 9999,
            border: '1px solid #333333',
            boxShadow: '0 4px 12px rgba(0,0,0,0.5)',
          }}
        >
          {shareToast}
        </div>
      )}

      <Header
        currentRoute={currentRoute}
        onNavigate={navigate}
        onShare={handleShare}
      />

      <main>
        {currentRoute === 'create' && (
          <CreatePage onNavigate={navigate} />
        )}
        {currentRoute === 'pay' && (
          <PayPage
            params={payParams}
            onNavigate={navigate}
          />
        )}
        {currentRoute === 'tos' && <TosPage />}
        {currentRoute === 'privacy-policy' && <PrivacyPolicyPage />}
      </main>

      <Footer currentRoute={currentRoute} onNavigate={navigate} />
    </div>
  );
};

export default App;
