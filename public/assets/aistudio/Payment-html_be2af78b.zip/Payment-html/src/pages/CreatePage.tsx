import React, { useState } from 'react';
import { type AppRoute } from '../types';

interface CreatePageProps {
  onNavigate: (route: AppRoute, queryParams?: { vpa?: string; amount?: string }) => void;
}

export const CreatePage: React.FC<CreatePageProps> = ({ onNavigate }) => {
  const [amount, setAmount] = useState('');
  const [isInvalid, setIsInvalid] = useState(false);

  const handleGenLink = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanAmount = amount.trim();

    if (cleanAmount !== '' && !isNaN(Number(cleanAmount)) && Number(cleanAmount) > 0) {
      setIsInvalid(false);
      // Directly show the preview checkout page with the entered amount
      onNavigate('pay', {
        amount: cleanAmount,
      });
    } else {
      setIsInvalid(true);
    }
  };

  return (
    <div style={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      {/* Pure White Card sitting on #FAF8F5 */}
      <form onSubmit={handleGenLink} className="white-card">
        <div className="amountdiv" style={{ margin: '8px 0 16px' }}>
          <p className="pdetailamount" style={{ color: '#000000', marginBottom: '8px' }}>
            Amount ={' '}
            <input
              type="number"
              id="amount"
              min="1"
              step="any"
              value={amount}
              onChange={(e) => {
                setAmount(e.target.value);
                if (isInvalid) setIsInvalid(false);
              }}
              placeholder="₹"
              className="amountbox"
              style={{ width: '100px', height: '42px', color: '#000000', fontWeight: 800, fontSize: '18px' }}
              autoFocus
              required
            />{' '}
            ₹
          </p>
        </div>

        <div className="center">
          <button type="submit" className="createb">
            C R E A T E
          </button>
          <p
            id="invalid"
            className="invalidtext"
            style={{ visibility: isInvalid ? 'visible' : 'hidden' }}
          >
            * Please enter a valid amount
          </p>
        </div>
      </form>

      {/* Clean T&C text and ONLY the official UPI logo */}
      <div style={{ textAlign: 'center', marginTop: '16px', padding: '0 10px', maxWidth: '360px' }}>
        <p className="smalltext" style={{ margin: '0 0 10px 0', fontSize: '11px', color: '#6B7280' }}>
          If you have any Question about security or privacy, Check our{' '}
          <a
            href="#tos"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('tos');
            }}
            style={{ color: '#000000', textDecoration: 'underline', fontWeight: 700 }}
          >
            T&C
          </a>
          .
        </p>

        {/* Only the official UPI logo */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <img
            src="/img/upi.svg"
            alt="UPI Logo"
            className="upilogo"
            width="50"
            height="25"
          />
        </div>
      </div>
    </div>
  );
};
