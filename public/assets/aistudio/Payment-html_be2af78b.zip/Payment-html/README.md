# Upier (React + Vite + TypeScript)

Upier is a free and secure platform to create & share UPI payment links and QR codes.

Rewritten as a modern React application with Vite, TypeScript, and client-side QR generation.

## Features

- **Instant UPI Link Generation**: Enter any VPA (UPI ID) and optional amount in INR.
- **Deep UPI Linking**: Direct `upi://pay?pn=...` integration triggering mobile payment apps (GPay, PhonePe, Paytm, BHIM, Cred, etc.).
- **Client-Side QR Code**: High-fidelity SVG QR codes generated on-the-fly directly in the browser with zero external API dependencies.
- **Copy & Share Support**: Instant clipboard copy and native Web Share API integration.
- **Privacy & Security**: Zero tracking, zero data sent to external servers, entirely processed within the browser.
- **Preserved Design**: Faithful reproduction of Upier's signature aesthetic and typography.

## Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Credits

- Original creator and design: [Tuhin Kanti Pal](https://tu.hin.life) ([cachecleanerjeet/Upier](https://github.com/cachecleanerjeet/Upier))
- Original idea inspired by [Upayi](https://github.com/cyberboysumanjay/upayi) by Sumanjay
- Rewritten for React in AI Studio
