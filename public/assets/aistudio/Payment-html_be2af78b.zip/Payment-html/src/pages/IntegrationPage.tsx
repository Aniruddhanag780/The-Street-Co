import React, { useState } from 'react';
import { type AppRoute } from '../types';

interface IntegrationPageProps {
  onNavigate: (route: AppRoute, queryParams?: { vpa?: string; amount?: string; orderId?: string; redirectUrl?: string }) => void;
}

export const IntegrationPage: React.FC<IntegrationPageProps> = ({ onNavigate }) => {
  const [testAmount, setTestAmount] = useState('499');
  const [testOrderId, setTestOrderId] = useState('ORD-1092');
  const [testRedirectUrl, setTestRedirectUrl] = useState('https://example.com/order-success');
  const [copiedCode, setCopiedCode] = useState(false);

  const baseUrl = window.location.origin;
  const generatedCheckoutUrl = `${baseUrl}/pay?amount=${encodeURIComponent(testAmount)}&orderId=${encodeURIComponent(testOrderId)}&redirectUrl=${encodeURIComponent(testRedirectUrl)}`;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(generatedCheckoutUrl);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2500);
    } catch {
      // ignore
    }
  };

  const handleTestInApp = () => {
    onNavigate('pay', {
      amount: testAmount,
      orderId: testOrderId,
      redirectUrl: testRedirectUrl,
    });
  };

  return (
    <div style={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <div className="white-card" style={{ maxWidth: '400px' }}>
        <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#111111', margin: '0 0 8px 0', textAlign: 'center' }}>
          E-Commerce Integration
        </h2>
        <p style={{ color: '#6B7280', fontSize: '12px', textAlign: 'center', margin: '0 0 16px 0', lineHeight: 1.4 }}>
          Generate test checkout links with custom amounts, order IDs, and your store's return URL.
        </p>

        {/* Interactive Link Tester */}
        <div
          style={{
            width: '100%',
            backgroundColor: '#F9F8F6',
            border: '1px solid #EBE7DF',
            borderRadius: '14px',
            padding: '14px',
            marginBottom: '16px',
          }}
        >
          <p style={{ color: '#111111', fontSize: '13px', fontWeight: 700, margin: '0 0 10px 0' }}>
            Test Parameters
          </p>

          <label style={{ display: 'block', color: '#6B7280', fontSize: '11px', fontWeight: 600, marginBottom: '4px' }}>
            Cart / Order Amount (₹):
          </label>
          <input
            type="number"
            value={testAmount}
            onChange={(e) => setTestAmount(e.target.value)}
            style={{
              width: '100%',
              height: '38px',
              backgroundColor: '#ffffff',
              border: '1px solid #D1D5DB',
              color: '#111111',
              borderRadius: '8px',
              padding: '0 10px',
              fontSize: '13px',
              marginBottom: '10px',
              outline: 'none',
            }}
          />

          <label style={{ display: 'block', color: '#6B7280', fontSize: '11px', fontWeight: 600, marginBottom: '4px' }}>
            Order ID:
          </label>
          <input
            type="text"
            value={testOrderId}
            onChange={(e) => setTestOrderId(e.target.value)}
            style={{
              width: '100%',
              height: '38px',
              backgroundColor: '#ffffff',
              border: '1px solid #D1D5DB',
              color: '#111111',
              borderRadius: '8px',
              padding: '0 10px',
              fontSize: '13px',
              marginBottom: '10px',
              outline: 'none',
            }}
          />

          <label style={{ display: 'block', color: '#6B7280', fontSize: '11px', fontWeight: 600, marginBottom: '4px' }}>
            Store Next Page (Redirect URL):
          </label>
          <input
            type="url"
            value={testRedirectUrl}
            onChange={(e) => setTestRedirectUrl(e.target.value)}
            placeholder="https://yourstore.com/order-success"
            style={{
              width: '100%',
              height: '38px',
              backgroundColor: '#ffffff',
              border: '1px solid #D1D5DB',
              color: '#111111',
              borderRadius: '8px',
              padding: '0 10px',
              fontSize: '13px',
              marginBottom: '12px',
              outline: 'none',
            }}
          />

          <div style={{ display: 'flex', gap: '8px' }}>
            <button
              type="button"
              onClick={handleTestInApp}
              className="createb"
              style={{
                flex: 1,
                backgroundColor: '#059669',
                color: '#ffffff',
                fontWeight: 700,
                padding: '10px 0',
                fontSize: '12px',
                margin: 0,
              }}
            >
              TEST CHECKOUT
            </button>
            <button
              type="button"
              onClick={handleCopyLink}
              className="secondary-btn"
              style={{ flex: 1, padding: '10px 0', fontSize: '12px' }}
            >
              {copiedCode ? 'COPIED URL!' : 'COPY URL'}
            </button>
          </div>
        </div>

        {/* How it works breakdown */}
        <div
          style={{
            width: '100%',
            backgroundColor: '#F9F8F6',
            border: '1px solid #EBE7DF',
            borderRadius: '14px',
            padding: '14px',
            marginBottom: '14px',
            textAlign: 'left',
          }}
        >
          <p style={{ color: '#111111', fontSize: '12px', fontWeight: 700, margin: '0 0 8px 0' }}>
            How Verification Works:
          </p>

          <ol style={{ color: '#4B5563', fontSize: '11px', paddingLeft: '16px', margin: 0, lineHeight: 1.6 }}>
            <li>
              <strong>Checkout Redirect</strong>: Your store redirects customers to{' '}
              <code style={{ color: '#059669', backgroundColor: '#ffffff', padding: '1px 4px', borderRadius: '4px' }}>
                /pay?amount=X&orderId=Y&redirectUrl=Z
              </code>
            </li>
            <li>
              <strong>UPI Payment</strong>: Customer scans QR or taps "Pay Via UPI App" using Google Pay, PhonePe, Paytm, etc.
            </li>
            <li>
              <strong>Verification</strong>: The customer submits their 12-digit UPI Reference / UTR Number.
            </li>
            <li>
              <strong>Automatic Return</strong>: Verified confirmation returns the user to your store with{' '}
              <code style={{ color: '#059669', backgroundColor: '#ffffff', padding: '1px 4px', borderRadius: '4px' }}>
                ?status=SUCCESS&orderId=...&utr=...
              </code>
            </li>
          </ol>
        </div>

        <button
          type="button"
          onClick={() => onNavigate('pay')}
          className="secondary-btn"
          style={{ width: '100%', padding: '10px 0', fontSize: '12px' }}
        >
          Back to Checkout
        </button>
      </div>
    </div>
  );
};
