import React from 'react';

export const TosPage: React.FC = () => {
  return (
    <div className="contentdiv-tos">
      <p className="txt">
        <a
          href="https://github.com/cachecleanerjeet/Upier"
          target="_blank"
          rel="noopener noreferrer"
        >
          Upier
        </a>{' '}
        is an Open Source Project. Anyone can create their service from{' '}
        <a
          href="https://github.com/cachecleanerjeet/Upier"
          target="_blank"
          rel="noopener noreferrer"
        >
          Upier
        </a>
        . Upier's Official domain is <span className="contact-email">upier.t-ps.net</span>.
      </p>

      <p className="txt">
        Upier official site <span className="contact-email">upier.t-ps.net</span> doesn't have any kind of tracking system or ad system, but I (Tuhin) can't assure that every site except <span className="contact-email">upier.t-ps.net</span> which are created from <span className="contact-email">github.com/cachecleanerjeet/Upier</span> are tracking free or ad free.
      </p>

      <p className="txt">
        Also, I can't track any kind of action that is doing from <span className="contact-email">upier.t-ps.net</span> by anyone.
      </p>

      <p className="txt">
        Upier doesn't send any Data to Server, All processes are encoded or decode in Client's Web Browser.
      </p>

      <p className="sign">- Tuhin Kanti Pal</p>
      <p className="signcontent">
        (Developer and Creator of{' '}
        <a
          href="https://github.com/cachecleanerjeet/Upier"
          target="_blank"
          rel="noopener noreferrer"
        >
          UPIER
        </a>
        )
        <br />
        <a
          href="https://github.com/cachecleanerjeet/"
          target="_blank"
          rel="noopener noreferrer"
        >
          G I T H U B
        </a>
      </p>

      <p className="txt">
        For contact send an email to:
        <br />
        <a href="mailto:me@thetuhin.com" className="contact-email">
          me@thetuhin.com
        </a>
      </p>

    </div>
  );
};
