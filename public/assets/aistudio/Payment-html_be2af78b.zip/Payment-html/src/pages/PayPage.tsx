import React, { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { DEFAULT_VPA, STORE_NAME, type AppRoute, type PayParams } from '../types';

interface PayPageProps {
  params: PayParams;
  onNavigate: (route: AppRoute) => void;
}

export const PayPage: React.FC<PayPageProps> = ({
  params,
  onNavigate,
}) => {
  // Permanent default UPI ID handled silently in the background
  const effectiveVpa = params.vpa && params.vpa.trim() !== '' ? params.vpa.trim() : DEFAULT_VPA;

  // Amount handling
  const [amountInput, setAmountInput] = useState<string>(params.amount || '');

  // 2-minute countdown timer (120 seconds)
  const [secondsLeft, setSecondsLeft] = useState<number>(120);

  useEffect(() => {
    if (params.amount) {
      setAmountInput(params.amount);
    }
  }, [params.amount]);

  useEffect(() => {
    if (secondsLeft <= 0) return;

    const timer = setInterval(() => {
      setSecondsLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    return () => clearInterval(timer);
  }, [secondsLeft]);

  const activeAmount = amountInput.trim();
  const hasValidAmount = activeAmount !== '' && !isNaN(Number(activeAmount)) && Number(activeAmount) > 0;

  // Format mm:ss
  const minutes = Math.floor(secondsLeft / 60);
  const seconds = secondsLeft % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  // Standard UPI intent URI
  const upiIntentUrl = hasValidAmount
    ? `upi://pay?pa=${effectiveVpa}&pn=${encodeURIComponent(STORE_NAME)}&am=${encodeURIComponent(activeAmount)}&cu=INR`
    : `upi://pay?pa=${effectiveVpa}&pn=${encodeURIComponent(STORE_NAME)}&cu=INR`;

  return (
    <div style={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      {/* Pure White Checkout Card */}
      <div className="white-card">
        {/* Amount in solid black text */}
        {hasValidAmount ? (
          <div style={{ textAlign: 'center', margin: '4px 0 12px 0' }}>
            <p style={{ fontSize: '32px', fontWeight: 800, color: '#000000', margin: 0, letterSpacing: '-0.5px' }}>
              ₹{activeAmount}
            </p>
          </div>
        ) : (
          <div style={{ width: '100%', marginBottom: '14px', textAlign: 'center' }}>
            <div style={{ display: 'flex', justifyContent: 'center', gap: '8px', alignItems: 'center' }}>
              <span style={{ fontSize: '24px', fontWeight: 800, color: '#000000' }}>₹</span>
              <input
                type="number"
                placeholder="0.00"
                value={amountInput}
                onChange={(e) => setAmountInput(e.target.value)}
                className="amountbox"
                style={{ width: '130px', height: '44px', fontSize: '20px', color: '#000000', fontWeight: 800 }}
                autoFocus
              />
            </div>
            <div style={{ display: 'flex', justifyContent: 'center', gap: '6px', marginTop: '8px' }}>
              {['199', '499', '999', '1499'].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setAmountInput(preset)}
                  style={{
                    backgroundColor: '#F6F4F0',
                    border: '1px solid #E6E2DA',
                    color: '#000000',
                    fontSize: '11px',
                    fontWeight: 700,
                    borderRadius: '8px',
                    padding: '4px 10px',
                    cursor: 'pointer',
                  }}
                >
                  ₹{preset}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* QR Code Container */}
        <div className="qr-container" style={{ margin: '4px auto 14px' }}>
          <QRCodeSVG
            value={upiIntentUrl}
            size={220}
            level="M"
            includeMargin={false}
            className="qrsvg"
          />
        </div>

        {/* Clickable Payment by any UPI app button */}
        <div className="center" style={{ width: '100%' }}>
          <a
            href={upiIntentUrl}
            className="paybutton"
            style={{
              display: 'block',
              width: '100%',
              backgroundColor: '#000000',
              color: '#ffffff',
              borderRadius: '12px',
              padding: '13px 0',
              textAlign: 'center',
              fontSize: '15px',
              fontWeight: 700,
              letterSpacing: '1px',
              textDecoration: 'none',
              cursor: 'pointer',
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
            }}
          >
            PAYMENT BY ANY UPI APP
          </a>

          {/* 2-Minute Checkout Timer replacing the back button */}
          <div style={{ marginTop: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke={secondsLeft < 30 ? '#DC2626' : '#6B7280'}
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="10" />
              <polyline points="12 6 12 12 16 14" />
            </svg>
            <span
              style={{
                fontSize: '12px',
                fontWeight: 600,
                color: secondsLeft < 30 ? '#DC2626' : '#6B7280',
                letterSpacing: '0.3px',
              }}
            >
              Checkout within {formattedTime}
            </span>
          </div>

          {secondsLeft === 0 && (
            <button
              type="button"
              onClick={() => setSecondsLeft(120)}
              style={{
                marginTop: '6px',
                background: 'transparent',
                border: 'none',
                color: '#000000',
                textDecoration: 'underline',
                fontSize: '11px',
                fontWeight: 700,
                cursor: 'pointer',
              }}
            >
              Refresh Timer
            </button>
          )}
        </div>
      </div>

      {/* Clean T&C text and ONLY the official UPI logo */}
      <div style={{ textAlign: 'center', marginTop: '16px', padding: '0 10px', maxWidth: '360px' }}>
        <p className="smalltext" style={{ margin: '0 0 10px 0', fontSize: '11px', color: '#6B7280' }}>
          If you have any Question about security or privacy, Check our{' '}
          <a
            href="#tos"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('tos');
            }}
            style={{ color: '#000000', textDecoration: 'underline', fontWeight: 700 }}
          >
            T&C
          </a>
          .
        </p>

        {/* Only the official UPI logo */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <img
            src="/img/upi.svg"
            alt="UPI Logo"
            className="upilogo"
            width="50"
            height="25"
          />
        </div>
      </div>
    </div>
  );
};
